clearvars;
clc;

Sb = 100.0;
fn = 50.0;
wn = 2*pi*fn;

% ----- Load model data ---------------------------------------------------
load('data_bus.mat');
load('data_lin.mat');
load('data_sm.mat');
load('data_avr.mat');
load('data_pss.mat');
load('data_tur.mat');
load('data_gfm.mat');
load('data_gfl.mat');
load('data_pmu.mat');

Nsm = size(Tsm,1);
Nbus = size(Tbus,1);
Nlin = size(Tlin,1);

index_sg = Tsm.BusID;
index_gfm = Tgfm.BusID;
index_gfl = Tgfl.BusID;
index_bs = find(Tbus.Type==3);
index_400 = find(Tbus.Vr>230);

% ----- Load powerflow solution -------------------------------------------
bus_sol = zeros(Nbus,7);
load("powerflow_sol.mat");
for i = 1:Nbus
    bus_sol(i,1) = i;
    bus_sol(i,2) = bus_results(i,3); % Vmag
    bus_sol(i,3) = bus_results(i,4); % Vang
    bus_sol(i,4) = bus_results(i,5); % Pgen
    bus_sol(i,5) = bus_results(i,6); % Qgen   
    bus_sol(i,6) = bus_results(i,7); % Ploa
    bus_sol(i,7) = bus_results(i,8); % Qloa
end

% ----- Assign synchronous machine parameters -----------------------------
Tsm.P = bus_sol(index_sg,4);
Tsm.Q = bus_sol(index_sg,5);
max_loading = 0.8;
for i = 1:Nsm
    Tsm.Sg(i) = sqrt(Tsm.P(i)^2+Tsm.Q(i)^2)*Sb;
    if Tsm.Sg(i) > Tsm.Sr(i)*max_loading
        fprintf('machine %d loaded at %f %% \n',i,Tsm.Sg(i)/Tsm.Sr(i)*100.0);
        Tsm.Sr(i) = Tsm.Sg(i)/max_loading;
    end
end
Tsm.Sr2Sb = Tsm.Sr/Sb;
Tsm.M = 2*Tsm.H;
Tsm.Yg = 1./(Tsm.Ra+1i*Tsm.Xd1);

% ----- Assign inverter-based resources (grid-forming) parameters ---------
Ngfm = numel(index_gfm);
Tgfm.Sr2Sb = Tgfm.Sr/Sb;
Tgfm.Kw(:) = 0;

% ----- Assign inverter-based resources (grid-following) parameters -------
Ngfl = numel(index_gfl);
Tgfl.Sr2Sb = Tgfl.Sr/Sb;

% ----- Configure active generation sources -------------------------------
Ninj = Nsm+Ngfm+Ngfl;
index_ibr = union(index_gfm,index_gfl);
index_inj = union(index_sg,index_ibr);
index_bs = setdiff(index_bs,index_ibr);

% ----- Configure PMUs ----------------------------------------------------
index_pmu = index_400;
index_pmu_bs = setdiff(index_pmu,index_inj);

% ----- Compute augmented admittance matrix -------------------------------
Y = build_admittance_matrix(Nbus,Tlin);
Ysm = zeros(Nbus,1);
Ysm(index_sg,1) = Tsm.Yg.*Tsm.Sr2Sb;
Ysm = diag(Ysm);
Ygfm = zeros(Nbus,1);
Ygfm(index_gfm,1) = Tgfm.Yf.*Tgfm.Sr2Sb;
Ygfm = diag(Ygfm);
Ygfl = zeros(Nbus,1);
Ygfl(index_gfl,1) = Tgfl.Yf.*Tgfl.Sr2Sb;
Ygfl = diag(Ygfl);
Vm = bus_sol(:,2);
Va = bus_sol(:,3);
Yload = diag((bus_sol(:,6)-1i*bus_sol(:,7))./Vm.^2);
Y_aug = Y+Yload+Ysm+Ygfm+Ygfl;

% ----- Compute synchronous machines initialization -----------------------
Tsm.Vm = bus_sol(index_sg,2);
Tsm.Va = bus_sol(index_sg,3);
Tsm.P = bus_sol(index_sg,4)./Tsm.Sr2Sb;
Tsm.Q = bus_sol(index_sg,5)./Tsm.Sr2Sb;
Tsm.Vxy = Tsm.Vm.*(cos(Tsm.Va)+1i*sin(Tsm.Va));
Tsm.Ixy = conj((Tsm.P+1i*Tsm.Q)./Tsm.Vxy);
Tsm.Eq0 = Tsm.Vxy+(Tsm.Ra+1i.*Tsm.Xq).*Tsm.Ixy;
Tsm.delta0 = angle(Tsm.Eq0);
Tsm.Iqd = Tsm.Ixy.*exp(-1i*Tsm.delta0);
Tsm.Iq0 = real(Tsm.Iqd);
Tsm.Id0 = imag(Tsm.Iqd);
Tsm.Vqd = Tsm.Vxy.*exp(-1i*Tsm.delta0);
Tsm.Vq0 = real(Tsm.Vqd);
Tsm.Vd0 = imag(Tsm.Vqd);
Tsm.Efd0 = abs(Tsm.Eq0)-(Tsm.Xd-Tsm.Xq).*Tsm.Id0;
Tsm.Eq_dash0 = Tsm.Efd0+(Tsm.Xd-Tsm.Xd1).*Tsm.Id0;
Tsm.Ed_dash0 = -(Tsm.Xq-Tsm.Xq1).*Tsm.Iq0;
Tsm.Pe0 = Tsm.Vq0.*Tsm.Iq0+Tsm.Vd0.*Tsm.Id0;
Tsm.Eqd_dash = Tsm.Eq_dash0+1i*Tsm.Ed_dash0;
Tsm.Eqd_internal = Tsm.Eqd_dash-1i*(Tsm.Xq1-Tsm.Xd1).*Tsm.Iq0;
Tsm.Igxy = Tsm.Yg.*Tsm.Vxy+Tsm.Ixy;
Tsm.Vref = Tsm.Vm;
Tsm.Pm0 = Tsm.Pe0;

% ----- Compute grid-forming converters initialization --------------------
Tgfm.Vm = bus_sol(index_gfm,2);
Tgfm.Va = bus_sol(index_gfm,3);
Tgfm.P = bus_sol(index_gfm,4)./Tgfm.Sr2Sb;
Tgfm.Q = bus_sol(index_gfm,5)./Tgfm.Sr2Sb;
Tgfm.Vxy = Tgfm.Vm.*(cos(Tgfm.Va)+1i*sin(Tgfm.Va));
Tgfm.Ixy = conj((Tgfm.P+1i*Tgfm.Q)./Tgfm.Vxy);
Tgfm.Exy_internal = Tgfm.Vxy+Tgfm.Ixy./Tgfm.Yf;
Tgfm.delta0 = angle(Tgfm.Exy_internal);
Tgfm.Idq = Tgfm.Ixy.*exp(-1i*Tgfm.delta0);
Tgfm.Vdq = Tgfm.Vxy.*exp(-1i*Tgfm.delta0);
Tgfm.Edq_internal = Tgfm.Exy_internal.*exp(-1i*Tgfm.delta0);
Tgfm.Igxy = Tgfm.Yf.*Tgfm.Vxy+Tgfm.Ixy;
Tgfm.Vref = Tgfm.Vm;
Tgfm.P0 = Tgfm.P;
Tgfm.Q0 = Tgfm.Q;

% ----- Compute grid-following converters initialization ------------------
Tgfl.Vm = bus_sol(index_gfl,2);
Tgfl.Va = bus_sol(index_gfl,3);
Tgfl.P = bus_sol(index_gfl,4)./Tgfl.Sr2Sb;
Tgfl.Q = bus_sol(index_gfl,5)./Tgfl.Sr2Sb;
Tgfl.Vxy = Tgfl.Vm.*(cos(Tgfl.Va)+1i*sin(Tgfl.Va));
Tgfl.Ixy = conj((Tgfl.P+1i*Tgfl.Q)./Tgfl.Vxy);
Tgfl.Exy_internal = Tgfl.Vxy+Tgfl.Ixy./Tgfl.Yf;
Tgfl.delta0 = angle(Tgfl.Exy_internal);
Tgfl.Idq = Tgfl.Ixy.*exp(-1i*Tgfl.delta0);
Tgfl.Vdq = Tgfl.Vxy.*exp(-1i*Tgfl.delta0);
Tgfl.Edq_internal = Tgfl.Exy_internal.*exp(-1i*Tgfl.delta0);
Tgfl.Igxy = Tgfl.Yf.*Tgfl.Vxy+Tgfl.Ixy;
Tgfl.Vref = Tgfl.Vm;
Tgfl.P0 = Tgfl.P;
Tgfl.Q0 = Tgfl.Q;

% ----- Compute Schur complement ------------------------------------------
Yaux = -Y_aug(index_bs,index_bs)\Y_aug(index_bs,index_inj);
Yred = Y_aug(index_inj,index_inj)+Y_aug(index_inj,index_bs)*Yaux;
% Zred = inv(Yred);
Zred = Yred\eye(Ninj,Ninj);

% ----- Configure disturbance ---------------------------------------------
idis = 2178;
Y_augd = Y_aug;
deltaP = 1000; % MW load increase
Y_augd(idis,idis) = Y_augd(idis,idis)+(deltaP/100)/(Vm(idis)^2);
Yauxd = -Y_augd(index_bs,index_bs)\Y_augd(index_bs,index_inj);
Yredd = Y_augd(index_inj,index_inj)+Y_augd(index_inj,index_bs)*Yauxd;
% Zredd = inv(Yredd);
Zredd = Yredd\eye(Ninj,Ninj);
index_pmu_bs_yaux = find(ismember(index_bs,index_pmu_bs));
Yaux_pmu = Yaux(index_pmu_bs_yaux,:);
Yauxd_pmu = Yauxd(index_pmu_bs_yaux,:);

% ----- Run simulation ----------------------------------------------------
sim('wamces_model.mdl');

% ----- Functions ---------------------------------------------------------
function Y = build_admittance_matrix(N,Tlin)
    Y = zeros(N,N);
    for k = 1:size(Tlin,1)
        i = Tlin.ID1(k);
        j = Tlin.ID2(k);
        r = Tlin.R(k);
        x = Tlin.X(k);
        z = r+1i*x;
        Y(i,j) = Y(i,j)-1/z;
        Y(j,i) = Y(j,i)-1/z;   
        Y(i,i) = Y(i,i)+1/z;
        Y(j,j) = Y(j,j)+1/z;
    end
end